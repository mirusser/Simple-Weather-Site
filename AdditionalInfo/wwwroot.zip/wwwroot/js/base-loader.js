﻿
function showBaseLoader(elementId) {

    $(elementId).html('<div style="display: flex; justify-content: center"><p><i class="fas fa-4x fa-sync-alt fa-spin"></i></p></div>');
}